# space counter
# logic 1

# print(input().count(" "))

# logic 2

# n=input()
# count=0
# for i in n:
#     if i==' ':
#         count+=1
# print(count)

#logic 3
# n=input()
# h=n.split()
# print(len(h)-1)

#logic 4


